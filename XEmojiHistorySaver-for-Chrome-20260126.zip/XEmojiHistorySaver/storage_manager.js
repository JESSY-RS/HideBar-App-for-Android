const StorageManager = {
    KEY: 'emoji_history',
    MAX_ITEMS: 100,

    async getHistory() {
        return new Promise((resolve) => {
            chrome.storage.local.get([this.KEY], (result) => {
                resolve(result[this.KEY] || []);
            });
        });
    },

    async addEmoji(emoji) {
        let history = await this.getHistory();

        // Remove existing to simulate "move to top"
        history = history.filter(e => e !== emoji);

        // Add to front
        history.unshift(emoji);

        // Limit size
        if (history.length > this.MAX_ITEMS) {
            history = history.slice(0, this.MAX_ITEMS);
        }

        return new Promise((resolve) => {
            chrome.storage.local.set({ [this.KEY]: history }, () => {
                resolve(history);
            });
        });
    },

    async removeEmoji(emoji) {
        let history = await this.getHistory();
        history = history.filter(e => e !== emoji);

        return new Promise((resolve) => {
            chrome.storage.local.set({ [this.KEY]: history }, () => {
                resolve(history);
            });
        });
    },

    async clearHistory() {
        return new Promise((resolve) => {
            chrome.storage.local.set({ [this.KEY]: [] }, () => {
                resolve([]);
            });
        });
    }
};

// Export for module usage if using ES modules, but for simple chrome ext direct inclusion:
// window.StorageManager = StorageManager;
