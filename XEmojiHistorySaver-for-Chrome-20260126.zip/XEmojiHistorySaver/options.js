// Save options to chrome.storage
function saveOptions() {
    const mode = document.querySelector('input[name="mode"]:checked').value;
    const fabTop = document.getElementById('fab-top').value;
    const fabRight = document.getElementById('fab-right').value;

    chrome.storage.local.set({
        action_mode: mode,
        fab_pos_top: fabTop,
        fab_pos_right: fabRight
    }, () => {
        // Update status to let user know options were saved.
        const status = document.getElementById('status');
        status.textContent = '設定を保存しました';
        setTimeout(() => {
            status.textContent = '';
        }, 2000);

        // Force background to update popup behavior immediately
        chrome.runtime.sendMessage({ action: 'update_popup_behavior' });
    });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restoreOptions() {
    chrome.storage.local.get({
        action_mode: 'popup', // default
        fab_pos_top: 1.5,
        fab_pos_right: 15
    }, (items) => {
        document.querySelector(`input[name="mode"][value="${items.action_mode}"]`).checked = true;
        document.getElementById('fab-top').value = items.fab_pos_top;
        document.getElementById('fab-right').value = items.fab_pos_right;
    });
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);
