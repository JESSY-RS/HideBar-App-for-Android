/**
 * X Emoji History Saver - Background Script
 */

// Initialize default settings & behavior
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(['show_fab', 'action_mode', 'app_theme'], (result) => {
        if (result.show_fab === undefined) {
            chrome.storage.local.set({ show_fab: true });
        }
        if (!result.action_mode) {
            chrome.storage.local.set({ action_mode: 'popup' });
        } else {
            updatePopupBehavior(result.action_mode);
        }
        // Create Context Menu for FAB visibility
        chrome.contextMenus.create({
            id: "toggle_fab",
            title: "フローティングボタンを表示/非表示",
            contexts: ["action"]
        });

        // Create Context Menu for Mode switching
        // Determine initial title based on current mode
        const modeTitle = (!result.action_mode || result.action_mode === 'popup')
            ? "動作モード切替 (現在: 標準ウィンドウ)"
            : "動作モード切替 (現在: ページ内ポップアップ)";

        chrome.contextMenus.create({
            id: "toggle_mode",
            title: modeTitle,
            contexts: ["action"]
        });
    });
});

// Function to switch between Popup and Overlay mode
function updatePopupBehavior(mode) {
    if (mode === 'overlay') {
        // Disable default popup (allows onClicked to fire)
        chrome.action.setPopup({ popup: '' });
    } else {
        // Enable default popup
        chrome.action.setPopup({ popup: 'popup.html' });
    }

    // Update Context Menu Title
    const newTitle = (mode === 'popup')
        ? "動作モード切替 (現在: 標準ウィンドウ)"
        : "動作モード切替 (現在: ページ内ポップアップ)";

    chrome.contextMenus.update("toggle_mode", { title: newTitle }, () => {
        if (chrome.runtime.lastError) {
            // Ignore error if menu doesn't exist yet
        }
    });
}

// Watch for changes (e.g. from Options page or Context Menu)
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.action_mode) {
        updatePopupBehavior(changes.action_mode.newValue);
    }
});

// Also listen for manual update message from options.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'update_popup_behavior') {
        chrome.storage.local.get(['action_mode'], (result) => {
            updatePopupBehavior(result.action_mode);
        });
    }
});

// Handle Toolbar Icon Click (Only fires if popup is empty/disabled)
chrome.action.onClicked.addListener((tab) => {
    // Send message to active tab to toggle overlay
    chrome.tabs.sendMessage(tab.id, { action: 'toggle_overlay' }).catch(err => {
        console.log('Could not send message to tab (probably restricted page):', err);
    });
});

// Handle Context Menu Click
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "toggle_fab") {
        chrome.storage.local.get(['show_fab'], (result) => {
            const newState = !result.show_fab;
            chrome.storage.local.set({ show_fab: newState });
        });
    } else if (info.menuItemId === "toggle_mode") {
        chrome.storage.local.get(['action_mode'], (result) => {
            const current = result.action_mode || 'popup';
            const next = (current === 'popup') ? 'overlay' : 'popup';
            chrome.storage.local.set({ action_mode: next });
        });
    } else if (info.menuItemId.startsWith("pos_")) {
        let top, right, bottom, left;
        // Reset all first
        // We will store explicit CSS values or specific keys.
        // Let's use 'fab_pos_top', 'fab_pos_right', 'fab_pos_bottom', 'fab_pos_left' null/value.

        switch (info.menuItemId) {
            case "pos_top_right":
                top = 1.5; right = 15; bottom = null; left = null;
                break;
            case "pos_bottom_right":
                top = null; right = 15; bottom = 20; left = null;
                break;
            case "pos_top_left":
                top = 1.5; right = null; bottom = null; left = 15;
                break;
            case "pos_bottom_left":
                top = null; right = null; bottom = 20; left = 15;
                break;
        }

        chrome.storage.local.set({
            fab_pos_top: top,
            fab_pos_right: right,
            fab_pos_bottom: bottom,
            fab_pos_left: left
        });
    }
});
