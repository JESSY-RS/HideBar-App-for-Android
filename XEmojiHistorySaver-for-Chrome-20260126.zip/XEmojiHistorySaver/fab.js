/**
 * X Emoji History Saver - Floating Action Button Script
 */

const FAB_ID = 'x-emoji-fab';
const OVERLAY_ID = 'x-emoji-overlay';

function createFAB() {
    if (document.getElementById(FAB_ID)) return;

    const fab = document.createElement('div');
    fab.id = FAB_ID;
    fab.title = 'Emoji History';

    // Default Flex (Always visible unless manually hidden by 5s rule)
    fab.style.display = 'flex';

    // Check storage for position
    chrome.storage.local.get(['show_fab', 'fab_pos_top', 'fab_pos_right'], (result) => {
        if (result.show_fab === false) {
            fab.style.display = 'none';
        }

        // Apply saved position if exists
        if (result.fab_pos_top !== undefined) {
            fab.style.top = `${result.fab_pos_top}px`;
        }
        if (result.fab_pos_right !== undefined) {
            fab.style.right = `${result.fab_pos_right}px`;
        }
    });

    fab.addEventListener('click', toggleOverlay);
    fab.addEventListener('mousedown', (e) => e.preventDefault());
    document.body.appendChild(fab);
}

// Listen for messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggle_overlay') {
        toggleOverlay();
    } else if (request.action === 'get_visibility') {
        const overlay = document.getElementById(OVERLAY_ID);
        // Check if overlay exists and is displayed (flex or block)
        const isVisible = overlay && (overlay.style.display !== 'none' && overlay.style.display !== '');
        sendResponse({ overlay: isVisible });
        return true; // Keep channel open just in case, though sync response usually fine
    } else if (request.action === 'preview_fab_position') {
        const fab = document.getElementById(FAB_ID);
        if (fab) {
            fab.style.top = `${request.top}px`;
            fab.style.right = `${request.right}px`;
            fab.style.bottom = 'auto';
            fab.style.left = 'auto';
        }
    } else if (request.action === 'preview_overlay_position') {
        const overlay = document.getElementById(OVERLAY_ID);
        if (overlay) {
            overlay.style.top = `${request.overlay_top}px`;
            overlay.style.right = `${request.overlay_right}px`;
            // Reset drag overrides
            overlay.style.left = 'auto';
            overlay.style.bottom = 'auto';
            // Force show overlay during preview if it exists
            overlay.style.display = 'flex';
        } else {
            // If overlay doesn't exist yet, create it
            createOverlay();
            loadEmojiHistory();
            const newOverlay = document.getElementById(OVERLAY_ID);
            newOverlay.style.top = `${request.overlay_top}px`;
            newOverlay.style.right = `${request.overlay_right}px`;
            newOverlay.style.display = 'flex';
        }
    } else if (request.action === 'set_visible') {
        const isVisible = request.visible;

        if (request.target === 'fab') {
            const fab = document.getElementById(FAB_ID);
            if (fab) {
                if (isVisible) {
                    fab.style.display = 'flex';
                    fab.style.opacity = '1';
                    fab.style.pointerEvents = 'auto';
                } else {
                    // Revert to storage state
                    chrome.storage.local.get(['show_fab'], (res) => {
                        if (res.show_fab === false) fab.style.display = 'none';
                    });
                }
            }
        } else if (request.target === 'overlay') {
            const overlay = document.getElementById(OVERLAY_ID);
            if (isVisible) {
                if (!overlay) {
                    createOverlay();
                    loadEmojiHistory();
                    document.getElementById(OVERLAY_ID).style.display = 'flex';
                } else {
                    overlay.style.display = 'flex';
                }
            } else {
                if (overlay) overlay.style.display = 'none';
            }
        }
    } else if (request.action === 'temporary_hide') {
        const fab = document.getElementById(FAB_ID);
        if (fab) {
            fab.style.opacity = '0';
            fab.style.pointerEvents = 'none'; // Prevent clicks while hidden

            setTimeout(() => {
                // Restore logic: check if it should be visible based on storage? 
                // For simplicity, just revert these. If user disabled it in meantime, storage listener would handle it?
                // Actually storage listener might overlap.
                // Let's just reset opacity/pointerEvents.
                fab.style.opacity = '1';
                fab.style.pointerEvents = 'auto';
            }, 5000);
        }
    }
});

// Listen for settings changes (Visible, Position)
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
        const fab = document.getElementById(FAB_ID);
        if (!fab) return;

        if (changes.show_fab) {
            fab.style.display = changes.show_fab.newValue ? 'flex' : 'none';

            // Toggle Hide Button in Overlay
            const hideBtn = document.getElementById('x-emoji-hide-5s');
            if (hideBtn) {
                hideBtn.style.display = changes.show_fab.newValue ? '' : 'none';
            }

            if (!changes.show_fab.newValue) {
                const overlay = document.getElementById(OVERLAY_ID);
                if (overlay) overlay.style.display = 'none';
            }
        }

        // Check for any position change (FAB)
        if (changes.fab_pos_top || changes.fab_pos_right || changes.fab_pos_bottom || changes.fab_pos_left) {
            chrome.storage.local.get(['fab_pos_top', 'fab_pos_right', 'fab_pos_bottom', 'fab_pos_left'], (result) => {
                applyFabPosition(fab, result);
            });
        }

        // Check for Overlay position change
        if (changes.overlay_pos_top || changes.overlay_pos_right) {
            const overlay = document.getElementById(OVERLAY_ID);
            if (overlay) {
                chrome.storage.local.get(['overlay_pos_top', 'overlay_pos_right'], (result) => {
                    overlay.style.top = result.overlay_pos_top ? `${result.overlay_pos_top}px` : overlay.style.top;
                    overlay.style.right = result.overlay_pos_right ? `${result.overlay_pos_right}px` : overlay.style.right;
                    // Reset others
                    overlay.style.left = 'auto';
                    overlay.style.bottom = 'auto';
                });
            }
        }

        // Close overlay if mode changes to 'popup' (Standard Window)
        if (changes.action_mode && changes.action_mode.newValue === 'popup') {
            const overlay = document.getElementById(OVERLAY_ID);
            if (overlay) {
                overlay.style.display = 'none';
                resetOverlayPosition(overlay);
            }
        }
    }
});

function applyFabPosition(fab, data) {
    if (data.fab_pos_top !== undefined && data.fab_pos_top !== null) fab.style.top = `${data.fab_pos_top}px`;
    else fab.style.top = 'auto'; // Reset if null

    if (data.fab_pos_right !== undefined && data.fab_pos_right !== null) fab.style.right = `${data.fab_pos_right}px`;
    else fab.style.right = 'auto';

    if (data.fab_pos_bottom !== undefined && data.fab_pos_bottom !== null) fab.style.bottom = `${data.fab_pos_bottom}px`;
    else fab.style.bottom = 'auto';

    if (data.fab_pos_left !== undefined && data.fab_pos_left !== null) fab.style.left = `${data.fab_pos_left}px`;
    else fab.style.left = 'auto';
}

function createOverlay() {
    if (document.getElementById(OVERLAY_ID)) return;

    const overlay = document.createElement('div');
    overlay.id = OVERLAY_ID;
    overlay.innerHTML = `
        <h2>
            絵文字履歴
            <span id="x-emoji-close">&times;</span>
        </h2>
        <div id="x-emoji-grid">Loading...</div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 5px; min-height: 20px;">
            <div id="x-emoji-status" style="font-size: 13px; color: #536471; margin: 0;"></div>
            <span id="x-emoji-hide-5s" class="x-emoji-hide-btn">ボタン5秒非表示</span>
        </div>
    `;

    // Prevent focus loss when clicking overlay background
    overlay.addEventListener('mousedown', (e) => {
        if (e.target.id !== 'x-emoji-grid') e.preventDefault();
    });

    document.body.appendChild(overlay);

    // Initial check for Hide Button visibility
    chrome.storage.local.get(['show_fab'], (res) => {
        const hideBtn = document.getElementById('x-emoji-hide-5s');
        if (hideBtn && res.show_fab === false) {
            hideBtn.style.display = 'none';
        }
    });

    // Close button logic
    document.getElementById('x-emoji-close').addEventListener('click', () => {
        overlay.style.display = 'none';
        resetOverlayPosition(overlay);
    });

    // Hide 5s Logic
    const hideBtn = document.getElementById('x-emoji-hide-5s');
    hideBtn.addEventListener('click', () => {
        overlay.style.display = 'none';
        resetOverlayPosition(overlay);

        const fab = document.getElementById(FAB_ID);
        if (fab) {
            fab.style.opacity = '0';
            fab.style.pointerEvents = 'none';
            setTimeout(() => {
                fab.style.opacity = '1';
                fab.style.pointerEvents = 'auto';
            }, 5000);
        }
    });

    // Hover Effects (Removed JS - handled by CSS)

    // --- Draggable Logic ---
    const header = overlay.querySelector('h2');
    let isDragging = false;
    let startX, startY, initialLeft, initialTop;

    header.addEventListener('mousedown', (e) => {
        // Allow close button to be clicked without dragging
        if (e.target.id === 'x-emoji-close') return;

        e.preventDefault(); // Prevent text selection
        isDragging = true;

        // Convert to absolute positions if not already set (handling initial right/bottom css)
        const rect = overlay.getBoundingClientRect();
        initialLeft = rect.left;
        initialTop = rect.top;

        // Remove 'right' and set explicit 'left'/'top' to allow free movement
        overlay.style.right = 'auto';
        overlay.style.bottom = 'auto';
        overlay.style.left = `${initialLeft}px`;
        overlay.style.top = `${initialTop}px`;

        startX = e.clientX;
        startY = e.clientY;

        // Add global listeners
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);

        header.style.cursor = 'grabbing';
    });

    function onMouseMove(e) {
        if (!isDragging) return;

        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        overlay.style.left = `${initialLeft + dx}px`;
        overlay.style.top = `${initialTop + dy}px`;
    }

    function onMouseUp() {
        isDragging = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        header.style.cursor = 'move';
    }
}

function resetOverlayPosition(overlay) {
    overlay.style.top = '';
    overlay.style.left = '';
    overlay.style.right = '';
    overlay.style.bottom = '';
}

function applyOverlayPosition(overlay, data) {
    if (data.overlay_pos_top !== undefined && data.overlay_pos_top !== null) overlay.style.top = `${data.overlay_pos_top}px`;
    if (data.overlay_pos_right !== undefined && data.overlay_pos_right !== null) overlay.style.right = `${data.overlay_pos_right}px`;

    // Reset left/bottom if setting top/right to ensure it takes precedence over any previous drag
    if (data.overlay_pos_top !== undefined || data.overlay_pos_right !== undefined) {
        overlay.style.left = 'auto';
        overlay.style.bottom = 'auto';
    }
}

function toggleOverlay() {
    const overlay = document.getElementById(OVERLAY_ID);

    chrome.storage.local.get(['overlay_pos_top', 'overlay_pos_right'], (result) => {
        if (!overlay) {
            createOverlay();
            const newOverlay = document.getElementById(OVERLAY_ID);
            applyOverlayPosition(newOverlay, result);
            loadEmojiHistory();
            newOverlay.style.display = 'flex';
        } else {
            if (overlay.style.display === 'none' || !overlay.style.display) {
                applyOverlayPosition(overlay, result);
                overlay.style.display = 'flex';
                loadEmojiHistory(); // Refresh on open
            } else {
                overlay.style.display = 'none';
                resetOverlayPosition(overlay);
            }
        }
    });
}

function loadEmojiHistory() {
    const grid = document.getElementById('x-emoji-grid');
    const statusMsg = document.getElementById('x-emoji-status');

    // Safety check for extension context
    try {
        if (!chrome.runtime || !chrome.runtime.id) {
            grid.innerText = 'Extension reloaded. Please refresh page.';
            return;
        }

        chrome.storage.local.get(['emoji_history'], (result) => {
            if (chrome.runtime.lastError) return;

            const history = result.emoji_history || [];
            grid.innerHTML = '';

            if (history.length === 0) {
                grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: left; color: gray; font-size: 14px; white-space: nowrap; padding: 10px;">履歴なし</div>';
                return;
            }

            history.forEach(emoji => {
                const div = document.createElement('div');
                div.className = 'emoji-item';
                div.textContent = emoji;

                // Click to insert
                div.addEventListener('mousedown', (e) => e.preventDefault());
                div.addEventListener('click', () => {
                    insertEmoji(emoji);
                    statusMsg.textContent = `Inserted: ${emoji}`;
                    setTimeout(() => statusMsg.textContent = '', 2000);
                });

                grid.appendChild(div);
            });
        });
    } catch (e) {
        console.error('Error loading history:', e);
    }
}

function insertEmoji(emoji) {
    // Attempt to find the active text area
    const active = document.activeElement;
    if (active && (active.tagName === 'TEXTAREA' || active.isContentEditable)) {
        insertAtCursor(active, emoji);
    } else {
        // Fallback: Try to find the main tweet composer
        const composer = document.querySelector('[data-testid="tweetTextarea_0"]') ||
            document.querySelector('[data-testid="dmComposerTextInput"]');
        if (composer) {
            composer.focus();
            insertAtCursor(composer, emoji);
        } else {
            // Last resort: Clipboard
            navigator.clipboard.writeText(emoji);
            alert('Could not find text area. Copied to clipboard.');
        }
    }
}

function insertAtCursor(element, text) {
    // execCommand is deprecated but still the most reliable for contentEditable on X
    const success = document.execCommand('insertText', false, text);

    if (!success) {
        // Fallback for simple inputs (though X uses contentEditable divs mostly)
        if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
            const start = element.selectionStart;
            const end = element.selectionEnd;
            const val = element.value;
            element.value = val.substring(0, start) + text + val.substring(end);
            element.selectionStart = element.selectionEnd = start + text.length;
            element.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
            // For contentEditable if execCommand fails (very rare in browsers)
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                range.deleteContents();
                range.insertNode(document.createTextNode(text));
                range.collapse(false);
                element.dispatchEvent(new Event('input', { bubbles: true }));
            }
        }
    }
}

// Initial Injection
// Use a slight delay or wait for idle to avoid interfering with initial page load
setTimeout(() => {
    createFAB();
}, 1500);

// Re-inject on navigation (SPA) is sometimes needed if body is cleared, 
// though usually X preserves body. We can observe body just in case.
const observer = new MutationObserver(() => {
    if (!document.getElementById(FAB_ID)) {
        createFAB();
    }
});
observer.observe(document.body, { childList: true });
