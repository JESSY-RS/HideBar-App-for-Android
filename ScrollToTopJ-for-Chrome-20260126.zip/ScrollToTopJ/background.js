// Default setting: Light Mode (Black Icon)
const MODE_LIGHT = 'light';
const MODE_DARK = 'dark';
const DEFAULT_MODE = MODE_LIGHT;

// Initialize context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MODE_LIGHT,
    title: "ライトモード",
    type: "radio",
    contexts: ["action"]
  });

  chrome.contextMenus.create({
    id: MODE_DARK,
    title: "ダークモード",
    type: "radio",
    contexts: ["action"]
  });

  // Set default selection
  chrome.storage.local.get(['themeMode'], (result) => {
    const currentMode = result.themeMode || DEFAULT_MODE;
    updateMenuSelection(currentMode);
    updateIcon(currentMode);
  });
});

// Also check on startup
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['themeMode'], (result) => {
    const currentMode = result.themeMode || DEFAULT_MODE;
    updateMenuSelection(currentMode);
    updateIcon(currentMode);
  });
});

// Handle menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const mode = info.menuItemId;
  if (mode === MODE_LIGHT || mode === MODE_DARK) {
    chrome.storage.local.set({ themeMode: mode });
    updateIcon(mode);
  }
});

// Helper to check radio button
function updateMenuSelection(mode) {
  // contextMenus.update call might fail if menu doesn't exist yet (race condition), but typically safe onInstalled
  chrome.contextMenus.update(mode, { checked: true }).catch(() => { });
}

// Update app icon based on mode
function updateIcon(mode) {
  const isDarkInfo = (mode === MODE_DARK);
  const suffix = isDarkInfo ? '_dark' : ''; // _dark png is White (for Dark Mode), normal is Black (for Light Mode)

  console.log(`[ScrollToTopJ] Setting mode to: ${mode}, Suffix: "${suffix}"`);

  const iconPaths = {
    "16": `images/icon16${suffix}.png`,
    "48": `images/icon48${suffix}.png`,
    "128": `images/icon128${suffix}.png`
  };

  chrome.action.setIcon({ path: iconPaths }).catch((err) => {
    console.error("[ScrollToTopJ] Failed to set icon:", err);
  });
}

// Action Click Handler
chrome.action.onClicked.addListener((tab) => {
  // restricted URL check
  if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:')) {
    return;
  }

  if (tab.id) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        window.scrollTo(0, 0);
      }
    }).catch(err => {
      // Catch other potential errors to avoid unhandled promise rejections
      console.log('Script injection failed: ', err);
    });
  }
});
